Caltech CS2 Assignment 6: Multithreading and Concurrency

See [assignment6.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/concurrency/blob/master/assignment6.html)
